
<a href='index.php?r=graph/'>Back To HomePage</a>

<br><br>
<br>Server Response Code: <b><?php echo $server_response['status']; ?></b>
<br>Server Message: <b><?php echo $server_response['message']; ?></b>
<hr>
SERVER LOG: 


<?php 

	print_r($server_response);


?>

<a href='index.php?r=graph/'>Back To HomePage</a>
