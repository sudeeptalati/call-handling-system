<?php
$this->breadcrumbs=array(
	'Configs'=>array('index'),
	'Create',
);




?>

<h1>Create Config</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>