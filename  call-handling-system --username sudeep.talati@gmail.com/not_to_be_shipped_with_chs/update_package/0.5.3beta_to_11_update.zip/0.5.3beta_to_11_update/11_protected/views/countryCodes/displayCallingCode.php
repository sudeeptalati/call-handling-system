<?php
echo $code;
?>