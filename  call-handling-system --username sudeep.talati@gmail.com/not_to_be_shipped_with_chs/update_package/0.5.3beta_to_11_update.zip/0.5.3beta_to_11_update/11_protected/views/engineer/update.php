
<div id="sidemenu">             
<?php include('setup_sidemenu.php'); ?>   
</div>

 

<h1>Update Engineer: <?php echo $model->first_name."  ".$model->last_name; ?></h1>
 

<div id="submenu">   
<li><?php echo CHtml::link('Manage Engineers',array('admin')); ?></li>
<li><?php echo CHtml::link('Add New Engineers',array('create')); ?></li>
</div>

<?php echo $this->renderPartial('_form', array('model'=>$model,'contactDetailsModel'=>$contactDetailsModel, 'deliveryDetailsModel'=>$deliveryDetailsModel)); ?>