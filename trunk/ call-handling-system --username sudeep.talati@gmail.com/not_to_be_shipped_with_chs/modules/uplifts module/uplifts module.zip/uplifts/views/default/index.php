             
<?php include('uplifts_menu.php'); ?>   
 

 <h1>Uplifts</h1>
 <p>
 This is the Uplifts Default Menu 
 
 
 </p>