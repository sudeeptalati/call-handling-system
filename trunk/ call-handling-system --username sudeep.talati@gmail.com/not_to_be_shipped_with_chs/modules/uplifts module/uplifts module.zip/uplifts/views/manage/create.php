<?php include('uplifts_menu.php'); ?>   

<h1>Raise Uplift Number</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>